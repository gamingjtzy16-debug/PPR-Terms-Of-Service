# PPR Terms of Service

This repository contains the public Terms of Service page for the Philippine Pampanga Roleplay Discord Bot.

## Publish with GitHub Pages

1. Create a new public GitHub repository.
2. Upload `index.html` to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish the site.
7. Use the resulting `https://<username>.github.io/<repository>/` address as the Terms of Service URL in the Discord Developer Portal.

Before publishing, confirm the Terms accurately reflect the Bot's actual features and operations. Add a real support contact or support-server link if available.
